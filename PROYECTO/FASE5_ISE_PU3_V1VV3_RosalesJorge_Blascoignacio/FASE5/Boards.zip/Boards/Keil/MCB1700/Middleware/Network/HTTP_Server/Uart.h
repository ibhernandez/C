#ifndef __UART_H
#define __UART_H

#include "LPC17xx.h"


/* Function to initialize the UART0 at specifief baud rate */
void uart_init(uint32_t baudrate);
/* Function to transmit a char */
void uart_TxChar(char ch);
/* Function to Receive a char */
char uart_RxChar();



#endif
