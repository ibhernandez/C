/*----------------------------------------------------------------------------
 * CMSIS-RTOS 'main' function template
 *---------------------------------------------------------------------------*/

#define osObjectsPublic                     // define objects in main module
#include "osObjects.h"                      // RTOS object definitions
#include "LCD.h"
#include "switch.h"
/*
 * main: initialize and start the system
 */
extern int Init_Thread(void);
int main (void) {

  osKernelInitialize ();                    // initialize CMSIS-RTOS
	//LAS SIGUIENTES FUNCIONES INICIALIZAN LOS PERIFERICOS USADOS, EN ORDEN LCD (+RESET), PWM, BUS I2C2, ADC, RADIO, PULSADORES
	init_lcd(); 
	LCD_reset();
	lcd_clean(); 
	initPulsador();
	Init_Thread (); //INICIALIZA LOS HILOS
  osKernelStart ();      	// start thread execution 

	
	while(1);
}
