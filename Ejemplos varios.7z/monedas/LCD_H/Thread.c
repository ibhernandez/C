
#include "cmsis_os.h"                                           // CMSIS RTOS header file
#include "LPC17xx.h"				//libreria de la placa
#include "GPIO_LPC17xx.h"		//libreria para el establecimiento de pines  
#include "PIN_LPC17xx.h"		//librer�a de los pines
#define MULT4 0x0004
#define CERO 	0x0008
#define STARTCUENTA 0x0001



#define FRECUENCIA 	4
#define SEGUNDOS 		2
#define PUERTO_LED 	1
#define LED_1				18
#define LED_2				20
#define LED_3				21
#define LED_4				23
/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/

uint32_t contador;
uint8_t valor;
uint8_t freqz=1000/(FRECUENCIA*2);
uint8_t repeticiones=SEGUNDOS*FRECUENCIA*2;
uint8_t sentido=0;
osEvent evnt;
void Thread_led(void const *argument);
void Thread_cuenta(void const *argument);         // thread function                       
void Thread_cero(void const *argument);
uint32_t seg=59;
uint32_t min=1;
osThreadId tid_Thread_cuenta;
osThreadDef (Thread_cuenta, osPriorityNormal,1 ,0);
osThreadId tid_Thread_led;
osThreadDef (Thread_led, osPriorityNormal,1 ,0);
osThreadId tid_Thread_cero;
osThreadDef (Thread_cero, osPriorityNormal, 1, 0);

int Init_Thread (void) {
	GPIO_SetDir(PUERTO_LED, LED_1, GPIO_DIR_OUTPUT);
	GPIO_SetDir(PUERTO_LED, LED_2, GPIO_DIR_OUTPUT);
	GPIO_SetDir(PUERTO_LED, LED_3, GPIO_DIR_OUTPUT);
	GPIO_SetDir(PUERTO_LED, LED_4, GPIO_DIR_OUTPUT);
  tid_Thread_cuenta = osThreadCreate (osThread(Thread_cuenta), NULL);
	tid_Thread_led = osThreadCreate (osThread(Thread_led), NULL);
	tid_Thread_cero = osThreadCreate (osThread(Thread_cero), NULL);
	osSignalSet(tid_Thread_cuenta,STARTCUENTA);
	if(!tid_Thread_cuenta||!tid_Thread_led) return(-1);
  return(0);
}

void Thread_cuenta(void const *argument) {
		osSignalWait(STARTCUENTA,osWaitForever);
		min=1;	
		seg=59;
    while(min==1||(min==0&&seg>0)){
		osDelay(1000);
  
		if(seg==0&&min>0){
			min--;
			seg=59;
		}
		if(min==0&&seg==0)
			osSignalSet(tid_Thread_cero, CERO);
		if((seg%4)==0&&min==1){
			osSignalSet(tid_Thread_led, MULT4);
		}	
		seg--; 
	}
}
void Thread_led(void const *argument){
	while(1){
		osSignalWait(MULT4, osWaitForever);
		valor=1;
		contador=repeticiones;
		while(contador<=repeticiones&&contador>0){
			GPIO_PinWrite(PUERTO_LED, LED_1, valor);
			osDelay(freqz);
			contador--;
			valor=!valor;
		}

	}
}

void Thread_cero(void const *argument){
	static uint32_t ticks=0;
	osSignalWait(CERO, osWaitForever);
	while(1){
		osDelay(250);

	if (sentido==0){
		switch(ticks++){
			//escribe en puerto 1 pin 18 el valor 1
			case 1:
				GPIO_PinWrite (PUERTO_LED, LED_1, 1);
				GPIO_PinWrite (PUERTO_LED, LED_2, 0);
				GPIO_PinWrite (PUERTO_LED, LED_3, 0);
				GPIO_PinWrite (PUERTO_LED, LED_4, 0);
					break;
			//escribe en puerto 1 pin 18 el valor 0
			case 2:
				GPIO_PinWrite (PUERTO_LED, LED_1, 0);
				GPIO_PinWrite (PUERTO_LED, LED_2, 1);
				GPIO_PinWrite (PUERTO_LED, LED_3, 0);
				GPIO_PinWrite (PUERTO_LED, LED_4, 0);
					break;
			case 3:
				GPIO_PinWrite (PUERTO_LED, LED_1, 0);
				GPIO_PinWrite (PUERTO_LED, LED_2, 0);
				GPIO_PinWrite (PUERTO_LED, LED_3, 1);
				GPIO_PinWrite (PUERTO_LED, LED_4, 0);
					break;
			case 4: 
				GPIO_PinWrite (PUERTO_LED, LED_1, 0);
				GPIO_PinWrite (PUERTO_LED, LED_2, 0);
				GPIO_PinWrite (PUERTO_LED, LED_3, 0);
				GPIO_PinWrite (PUERTO_LED, LED_4, 1);
				sentido=!sentido;
			ticks=3;
			break;
			}
					
			}
	else {
		switch(ticks--){
			//escribe en puerto 1 pin 18 el valor 1
			case 3:
				GPIO_PinWrite (PUERTO_LED, LED_1, 0);
				GPIO_PinWrite (PUERTO_LED, LED_2, 0);
				GPIO_PinWrite (PUERTO_LED, LED_3, 0);
				GPIO_PinWrite (PUERTO_LED, LED_4, 1);

					break;
			//escribe en puerto 1 pin 18 el valor 0
			case 2:
				GPIO_PinWrite (PUERTO_LED, LED_1, 0);
				GPIO_PinWrite (PUERTO_LED, LED_2, 0);
				GPIO_PinWrite (PUERTO_LED, LED_3, 1);
				GPIO_PinWrite (PUERTO_LED, LED_4, 0);
					break;
			case 1:
				GPIO_PinWrite (PUERTO_LED, LED_1, 0);
				GPIO_PinWrite (PUERTO_LED, LED_2, 1);
				GPIO_PinWrite (PUERTO_LED, LED_3, 0);
				GPIO_PinWrite (PUERTO_LED, LED_4, 0);
					break;
			case 0: 
				GPIO_PinWrite (PUERTO_LED, LED_1, 1);
				GPIO_PinWrite (PUERTO_LED, LED_2, 0);
				GPIO_PinWrite (PUERTO_LED, LED_3, 0);
				GPIO_PinWrite (PUERTO_LED, LED_4, 0);
				sentido=!sentido;
				ticks=1;
					break;
			}
		}
	}
}


