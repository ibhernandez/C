/*----------------------------------------------------------------------------
 * CMSIS-RTOS 'main' function template
 *---------------------------------------------------------------------------*/

#include "osObjects.h"                      // RTOS object definitions
#include "LCD.h"

extern int Init_Thread(void);
extern osThreadId tid_Thread_bc;
extern uint32_t seg;
extern uint32_t min;

char L1[128];	//El m�ximo de caracteres pueden ser 128 por linea, en concreto 128 exclamaciones (!)
char L2[128];
uint32_t numero1=1234;
float numero2= 3.14159;
int j;
uint8_t recoger1;
uint16_t recoger2;
int main (){
 	osKernelInitialize (); // initialize CMSIS-RTOS
	init();
 	LCD_reset();                
	Init_Thread();
  osKernelStart ();                         // start thread execution 
	
	
while(1){
	 posicion_l2_reset();
	osDelay(1000);
	sprintf(L2,"Crono-> %0.2d:%0.2d", min, seg);
		for (j=0; j<strlen(L2);j++){
		recoger2= (uint8_t)L2[j];
		EscribeLetra_L2(recoger2);
			
		
	}
	copy_to_lcd();	
}
}

