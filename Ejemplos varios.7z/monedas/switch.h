#ifndef __SWITCH_H
#define __SWITCH_H

#include "osObjects.h"                      // RTOS object definitions
#include "LPC17xx.h"				//libreria de la placa
#include "GPIO_LPC17xx.h"		//libreria para el establecimiento de pines  
#include "PIN_LPC17xx.h"		//librer�a de los pines

#define up 		0x0001	//00001
#define dw	 	0x0002	//00010
#define rg 		0x0004	//00100
#define lf 		0x0008	//01000
#define upf 	0x0010	//...00010000
#define dwf 	0x0020	//...00100000
#define rgf		0x0040	//...01000000
#define lff		0x0080	//...10000000
#define md		0x0100
#define mdf		0x0200

#define PUERTO_JOY	0			//los valores en comentarios son los que te da el fabricante
#define JOY_DW			17		//17
#define JOY_LF			15		//15
#define JOY_RG			24		//24	
#define JOY_UP			23		//23
#define JOY_MD			16

extern osThreadId tid_Thread_sw;

//Funciones 
void initPulsador(void);
void EINT3_IRQHandler (void);

#endif
