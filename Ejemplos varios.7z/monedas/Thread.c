
#include "cmsis_os.h"                                           // CMSIS RTOS header file
#include "switch.h"
#include "LCD.h"

#define PORTLED		1
#define	PINLED		18
void Thread_manual(void const *argument);
void periodico(void const *argument);
void once(void const *argument);
//VARIABLES GLOBALES
bool comenzado=false;
bool bloqueado=false;
float cn=0, ce=0, co=0, cs=0;
osEvent evnt;
osThreadId tid_Thread_sw;
osThreadDef (Thread_manual, osPriorityNormal, 1,0);
osTimerId tid_periodico;
osTimerDef(Timer1s, periodico);
void Init_Thread(void){

	//ConfiguracionLED1
	GPIO_SetDir(PORTLED, PINLED, GPIO_DIR_OUTPUT);
	//THREADS
	tid_Thread_sw=osThreadCreate (osThread (Thread_manual), NULL);
	//TIMERS
	tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, NULL);
	escribir_modo();
}

void periodico(void const *argument){
	osTimerStop(tid_periodico);
	lcd_clean();
	escribir_modo();
	cn=cs=ce=co=0;
	comenzado=false;
	
}

void Thread_manual(void const *argument){	
	uint8_t indice=2;
	while(1){
		evnt = osSignalWait(0, osWaitForever);
		switch (evnt.value.signals){
			case up:																				//PULSACION ARRIBA, EMITE UN BIP Y ECUTA SEEKUP, ADEMAS COONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_UP);
				if(!comenzado){
					osTimerStart(tid_periodico, 30000);
					comenzado=true;
				}
				cn+=2;
				escribir_frecuencia(cn, ce, co, cs);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_UP);	
				break;
			case dw:																				//PULSACION ABAJO, EMITE UN BIP Y EJECUTA SEEK DOWN, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_DW);
				if(!comenzado){
					osTimerStart(tid_periodico, 30000);
					comenzado=true;
				}
				cs+=1;
				escribir_frecuencia(cn, ce, co, cs);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_DW);	
				break;

			case rg:																			//PULSACION DERECHA, EMITE UN BIP Y AUMENTA LA FRECUENCIA EN 100Hz, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_RG);
				if(!comenzado){
					osTimerStart(tid_periodico, 30000);
					comenzado=true;
				}
				ce+=0.5;
				escribir_frecuencia(cn, ce, co, cs);			
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_RG);
				break;
			case lf:																	//PUSALCION IZQUIERDA, EMITE UN BIP Y DISMINUYE LA FRECUENCIA 100Hz, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_LF);
				if(!comenzado){
					osTimerStart(tid_periodico, 30000);
					comenzado=true;
				}
				co+=0.2;
				escribir_frecuencia(cn, ce, co, cs);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_LF);	
				break;
			case md:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_MD);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_MD);	
			break;
			case upf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_UP);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_UP);			
				break;
			case dwf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_DW);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_DW);	
				break;
			case rgf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_RG);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_RG);	
				break;
			case lff:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_LF);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_LF);	
				break;
			case mdf:															//PULSACION CENTRAL, PASA A MODO AUTOMATICO HACE UN BIP Y PARA EL THREAD DE MANUAL
				osDelay(150);												//SE HACE EN EL FLANCO DE BAJADA PARA QUE ESTE HABILITE DE NUEVO EL FLANCO DE SUBIDA, DE LO CONTRARIO EL PUSLADOR QUEDARIA DESHABILITADO
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_MD);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_MD);	
				break;
			
			default:
				break;
		}	
	}
}


