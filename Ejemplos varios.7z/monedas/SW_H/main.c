/*----------------------------------------------------------------------------
 * CMSIS-RTOS 'main' function template
 *---------------------------------------------------------------------------*/

#include "switch.h"






/*
 * main: initialize and start the system
 */
int main (void) {
  osKernelInitialize ();                    // initialize CMSIS-RTOS
	Init_Thread();
  osKernelStart ();                         // start thread execution 
	initPulsador();
	while(1);
}

