
#include "cmsis_os.h"                                           // CMSIS RTOS header file
#include "switch.h"
#include "LCD.h"

#define PORTLED		1
#define	PINLED		18
void Thread_manual(void const *argument);
void periodico(void const *argument);
void once(void const *argument);
//VARIABLES GLOBALES
uint8_t seg=59;
uint8_t min=1;
uint8_t hora=13;
osEvent evnt;
uint32_t ciclos[5]={100, 300, 500, 700, 900};
	
osThreadId tid_Thread_sw;
osThreadDef (Thread_manual, osPriorityNormal, 1,0);
osTimerId tid_periodico, tid_once;
osTimerDef(Timer1s, periodico);
osTimerDef(Timerxs, once);

void Init_Thread(void){

	//ConfiguracionLED1
	GPIO_SetDir(PORTLED, PINLED, GPIO_DIR_OUTPUT);
	//THREADS
	tid_Thread_sw=osThreadCreate (osThread (Thread_manual), NULL);
	//TIMERS
	tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, &ciclos[2]);
	escribir_frecuencia(ciclos[2]/10);
	tid_once=osTimerCreate(osTimer(Timerxs), osTimerOnce, NULL);
	osTimerStart(tid_periodico, 1000);
}

void periodico(void const *argument){
	GPIO_PinWrite(PORTLED, PINLED, 1);
	osTimerStart(tid_once, *(uint32_t *)argument);
	
}
void once(void const *argument){
	GPIO_PinWrite(PORTLED, PINLED, 0);
}

void Thread_manual(void const *argument){	
	uint8_t indice=2;
	while (1) {
		evnt = osSignalWait(0, osWaitForever);
		switch (evnt.value.signals){
			case up:																				//PULSACION ARRIBA, EMITE UN BIP Y ECUTA SEEKUP, ADEMAS COONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_UP);
				osTimerStop(tid_periodico);
				osTimerDelete(tid_periodico);
				if(indice==4) indice=0;
				else indice++;
				tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, &ciclos[indice]);
				osTimerStart(tid_periodico, 1000);
				escribir_frecuencia(ciclos[indice]/10);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_UP);	
				break;
			case dw:																				//PULSACION ABAJO, EMITE UN BIP Y EJECUTA SEEK DOWN, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_DW);
				osTimerStop(tid_periodico);
				osTimerDelete(tid_periodico);
				if(indice==0) indice=4;
				else indice--;
				tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, &ciclos[indice]);
				osTimerStart(tid_periodico, 1000);
				escribir_frecuencia(ciclos[indice]/10);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_DW);	
				break;

			case rg:																			//PULSACION DERECHA, EMITE UN BIP Y AUMENTA LA FRECUENCIA EN 100Hz, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_RG);			
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_RG);
				break;
			case lf:																	//PUSALCION IZQUIERDA, EMITE UN BIP Y DISMINUYE LA FRECUENCIA 100Hz, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_LF);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_LF);	
				break;
			case md:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_MD);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_MD);	
			break;
			case upf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_UP);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_UP);			
				break;
			case dwf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_DW);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_DW);	
				break;
			case rgf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_RG);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_RG);	
				break;
			case lff:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_LF);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_LF);	
				break;
			case mdf:															//PULSACION CENTRAL, PASA A MODO AUTOMATICO HACE UN BIP Y PARA EL THREAD DE MANUAL
				osDelay(150);												//SE HACE EN EL FLANCO DE BAJADA PARA QUE ESTE HABILITE DE NUEVO EL FLANCO DE SUBIDA, DE LO CONTRARIO EL PUSLADOR QUEDARIA DESHABILITADO
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_MD);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_MD);	
				break;
			
			default:
				break;
		}	
	}
}


