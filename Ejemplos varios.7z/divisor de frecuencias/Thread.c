
#include "cmsis_os.h"                                           // CMSIS RTOS header file
#include "switch.h"
#include "LCD.h"

#define PORTLED		1
#define	PINLED		18
void Thread_manual(void const *argument);
void periodico(void const *argument);
void automatico (void const *argument);
//VARIABLES GLOBALES

osEvent evnt;
uint32_t ciclos[5]={500, 1000, 1500, 2000, 2500};
uint8_t valor=0;
uint8_t indice=2;
osThreadId tid_Thread_sw;
osThreadDef (Thread_manual, osPriorityNormal, 1,0);
osTimerId tid_periodico, tid_automatico;
osTimerDef(Timer1s, periodico);
osTimerDef(Timer10s, automatico);


void Init_Thread(void){

	//ConfiguracionLED1
	GPIO_SetDir(PORTLED, PINLED, GPIO_DIR_OUTPUT);
	//THREADS
	tid_Thread_sw=osThreadCreate (osThread (Thread_manual), NULL);
	//TIMERS
	tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, NULL);
	escribir_frecuencia(2*ciclos[2]/1000);
	osTimerStart(tid_periodico, ciclos[2]);
	
	tid_automatico=osTimerCreate(osTimer(Timer10s), osTimerPeriodic, NULL);
	osTimerStart(tid_automatico, 10000);
}

void periodico(void const *argument){

	GPIO_PinWrite(PORTLED, PINLED, valor);
	valor= !valor;
}
void automatico(void const *argument){
		osTimerStop(tid_periodico);
		osTimerDelete(tid_periodico);
		if(indice==4) indice=0;
		else indice++;
		tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, NULL);
		osTimerStart(tid_periodico, ciclos[indice]);
		escribir_frecuencia(2*ciclos[indice]/1000);
}

void Thread_manual(void const *argument){	
	while (1) {
		evnt = osSignalWait(0, osWaitForever);
		switch (evnt.value.signals){
			case up:
				osTimerStop(tid_automatico);																			//PULSACION ARRIBA, EMITE UN BIP Y ECUTA SEEKUP, ADEMAS COONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_UP);
				osTimerStop(tid_periodico);
				osTimerDelete(tid_periodico);
				if(indice==4) indice=0;
				else indice++;
				tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, NULL);
				osTimerStart(tid_periodico, ciclos[indice]);
				escribir_frecuencia(2*ciclos[indice]/1000);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_UP);	
				osTimerStart(tid_automatico, 10000);
				break;
			case dw:
				osTimerStop(tid_automatico);																			//PULSACION ABAJO, EMITE UN BIP Y EJECUTA SEEK DOWN, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_DW);
				osTimerStop(tid_periodico);
				osTimerDelete(tid_periodico);
				if(indice==0) indice=4;
				else indice--;
				tid_periodico=osTimerCreate(osTimer(Timer1s), osTimerPeriodic, NULL);
				osTimerStart(tid_periodico, ciclos[indice]);
				escribir_frecuencia(2*ciclos[indice]/1000);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_DW);	
				osTimerStart(tid_automatico, 10000);
				break;

			case rg:																			//PULSACION DERECHA, EMITE UN BIP Y AUMENTA LA FRECUENCIA EN 100Hz, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_RG);			
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_RG);
				break;
			case lf:																	//PUSALCION IZQUIERDA, EMITE UN BIP Y DISMINUYE LA FRECUENCIA 100Hz, ADEMAS CONTROLA EL ACCESO AL BUS I2C
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_LF);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_LF);	
				break;
			case md:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnF |=(1<<JOY_MD);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_MD);	
			break;
			case upf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_UP);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_UP);			
				break;
			case dwf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_DW);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_DW);	
				break;
			case rgf:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_RG);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_RG);	
				break;
			case lff:
				osDelay(150);
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_LF);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_LF);	
				break;
			case mdf:															//PULSACION CENTRAL, PASA A MODO AUTOMATICO HACE UN BIP Y PARA EL THREAD DE MANUAL
				osDelay(150);												//SE HACE EN EL FLANCO DE BAJADA PARA QUE ESTE HABILITE DE NUEVO EL FLANCO DE SUBIDA, DE LO CONTRARIO EL PUSLADOR QUEDARIA DESHABILITADO
				LPC_GPIOINT->IO0IntEnR |=(1<<JOY_MD);
				LPC_GPIOINT-> IO0IntClr|=(1<<JOY_MD);	
				break;
			
			default:
				break;
		}	
	}
}


