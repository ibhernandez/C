#ifndef __LCD_H
#define __LCD_H

#include "LPC17xx.h"
#include "GPIO_LPC17xx.h"
#include "PIN_LPC17xx.h"
#include "stdio.h"
#define PUERTO			0
#define PIN_RESET			8
#define PIN_A0 				6 
#define PIN_CS			18



//FUNCIONES
void init_lcd(void);
void wr_data(unsigned char data);
void wr_cmd(unsigned char cmd);
void LCD_reset(void);
void copy_to_lcd(void);
int EscribeLetra_L1 (uint8_t letra);
void posicion_l2_reset(void);
int EscribeLetra_L2 (uint16_t letra);
void escribir_frecuencia(uint16_t norte, uint16_t sur, uint16_t este, uint16_t oeste);
void lcd_clean(void);
void escribir_modo(uint16_t norte, uint16_t sur, uint16_t este, uint16_t oeste);
#endif
